﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using TesteSeusConhecimentos.Domain;
using TesteSeusConhecimentos.Infra;

namespace TesteSeusConhecimentos.Web.Infocast
{
    public partial class Relacionamentos : System.Web.UI.Page
    {
        private IRelacionamentoRepository relacionamentoRepository;
        public Relacionamentos()
        {
            this.relacionamentoRepository = new RelacionamentoRepository();
        }
        protected void Page_Load(object sender, EventArgs e)
        {
            if(!IsPostBack)
            {
                UpdateGridRelacionamentos();
            }
        }

        protected void btnNovo_Click(object sender, EventArgs e)
        {
            Response.Redirect("~/Infocast/InfoRelacionamentos.aspx");
        }

        private void UpdateGridRelacionamentos()
        {
            var relacionamentos = relacionamentoRepository.GetAll();
            grdRelacionamentos.DataSource = relacionamentos;
            grdRelacionamentos.DataBind();
        }

        protected void grdRelacionamentos_RowCommand(object sender, GridViewCommandEventArgs e)
        {
            int idRelacionamento = Convert.ToInt32(e.CommandArgument);

            switch (e.CommandName)
            {
                case ("Remove"):
                    relacionamentoRepository.Delete(idRelacionamento);
                    UpdateGridRelacionamentos();
                    break;
                case ("Edit"):
                    Response.Redirect("~/Infocast/InfoRelacionamentos.aspx?id=" + idRelacionamento, true);
                    break;
            }
        }
    }
}