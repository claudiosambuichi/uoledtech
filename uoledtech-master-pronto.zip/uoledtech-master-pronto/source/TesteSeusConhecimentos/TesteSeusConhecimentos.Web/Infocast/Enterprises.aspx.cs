﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using TesteSeusConhecimentos.Domain;
using TesteSeusConhecimentos.Infra;

namespace TesteSeusConhecimentos.Web.Infocast
{
    public partial class Enterprises : System.Web.UI.Page
    {
        private IEnterpriseRepository enterpriseRepository;
        public Enterprises()
        {
            this.enterpriseRepository = new EnterpriseRepository();
        }
        protected void Page_Load(object sender, EventArgs e)
        {
            if(!IsPostBack)
            {
                UpdateGridEnterprise();
            }

        }

        protected void grdEnterprise_RowCommand(object sender, GridViewCommandEventArgs e)
        {
            int idEmpresa = Convert.ToInt32(e.CommandArgument);

            switch (e.CommandName)
            {
                case ("Remove"):
                    enterpriseRepository.Delete(idEmpresa);
                    UpdateGridEnterprise();
                    break;
                case ("Edit"):
                    Response.Redirect("~/Infocast/InfoEnterprise.aspx?id=" + idEmpresa, true);
                    break;
            }
        }

        private void UpdateGridEnterprise()
        {
            var empresas = enterpriseRepository.GetAll();
            grdEnterprise.DataSource = empresas;
            grdEnterprise.DataBind();
        }

        protected void btnNew_Click(object sender, EventArgs e)
        {
            Response.Redirect("~/Infocast/InfoEnterprise.aspx");
        }
    }
}