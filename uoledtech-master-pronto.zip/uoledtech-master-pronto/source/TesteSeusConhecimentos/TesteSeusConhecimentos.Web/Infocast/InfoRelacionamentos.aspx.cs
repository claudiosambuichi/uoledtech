﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using TesteSeusConhecimentos.Domain;
using TesteSeusConhecimentos.Entities;
using TesteSeusConhecimentos.Infra;

namespace TesteSeusConhecimentos.Web.Infocast
{
    public partial class InfoRelacionamentos : System.Web.UI.Page
    {
        private IRelacionamentoRepository relacionamentoRepository;
        private IEnterpriseRepository enterpriseRepository;
        private IUserRepository userRepository;

        public InfoRelacionamentos()
        {
            this.relacionamentoRepository = new RelacionamentoRepository();
            this.enterpriseRepository = new EnterpriseRepository();
            this.userRepository = new UserRepository();
        }

        private int idRelacionamento
        {
            set { ViewState["idRelacionamento"] = value; }
            get
            {
                if (ViewState["idRelacionamento"] != null)
                    return Convert.ToInt32(ViewState["idRelacionamento"]);

                return 0;
            }
        }

        protected void Page_Load(object sender, EventArgs e)
        {
            if(!IsPostBack)
            {
                SetViewStateRelacionamento();
                CarregarDdls();
            }
        }

        private void SetViewStateRelacionamento()
        {
            if (Request.QueryString["id"] != null)
                idRelacionamento = Convert.ToInt32(Request.QueryString["id"]);
            else
                idRelacionamento = 0;
        }

        private void CarregarDdls()
        {
            var users = userRepository.GetAll();
            var empresas = enterpriseRepository.GetAll();

            ListItem i = new ListItem("Selecione", "0", true);
            
            ddlEnterprises.DataSource = empresas;
            ddlEnterprises.DataValueField = "IdEnterprise";
            ddlEnterprises.DataTextField = "StreetAdress";
            ddlEnterprises.DataBind();
            ddlEnterprises.Items.Insert(0, i);


            ddlUsers.DataSource = users;
            ddlUsers.DataValueField = "IdUser";
            ddlUsers.DataTextField = "Name";
            ddlUsers.DataBind();
            ddlUsers.Items.Insert(0,i);


            if (idRelacionamento != 0)
            {
                var relacionamento = relacionamentoRepository.GetById(idRelacionamento);
                ddlUsers.SelectedValue = relacionamento.Usuario.IdUser.ToString();
                ddlEnterprises.SelectedValue = relacionamento.Empresa.IdEnterprise.ToString();
            }
            else
            {
                ddlUsers.SelectedValue = "0";
                ddlEnterprises.SelectedValue = "0";
            }
        }

        protected void btnRelacionar_Click(object sender, EventArgs e)
        {
            var user = userRepository.GetById(Convert.ToInt32(ddlUsers.SelectedValue));
            var empresa = enterpriseRepository.GetById(Convert.ToInt32(ddlEnterprises.SelectedValue));
            Relacionamento relacionamento = new Relacionamento(idRelacionamento, user, empresa);
            relacionamentoRepository.Save(relacionamento);
            Response.Redirect("~/Infocast/Relacionamentos.aspx");
        }
    }
}