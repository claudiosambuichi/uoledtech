﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using NHibernate;
using TesteSeusConhecimentos.Domain;
using TesteSeusConhecimentos.Entities;
using NHibernate.Linq;

namespace TesteSeusConhecimentos.Infra
{
    public class RelacionamentoRepository : IRelacionamentoRepository
    {
        public RelacionamentoRepository()
        {

        }

        public IList<Relacionamento> GetAll()
        {
            using (ISession session = FluentSessionFactory.abrirSession())
            {
                return (from e in session.Query<Relacionamento>() select e).ToList();
            }
        }


        public Relacionamento GetById(int id)
        {

            using (ISession session = FluentSessionFactory.abrirSession())
            {
                return session.Get<Relacionamento>(id);
            }
        }


        public void Delete(int id)
        {

            using (ISession session = FluentSessionFactory.abrirSession())
            {
                using (ITransaction transacao = session.BeginTransaction())
                {
                    try
                    {
                        Relacionamento relacionamento = session.Get<Relacionamento>(id);
                        if (relacionamento != null)
                        {
                            session.Delete(relacionamento);
                            transacao.Commit();
                        }
                    }
                    catch (Exception e)
                    {
                        if (!transacao.WasCommitted)
                        {
                            transacao.Rollback();
                        }
                        throw new Exception("Erro ao deletar relacionamento: " + e.Message);
                    }
                }
            }
        }

        public void Save(Relacionamento relacionamento)
        {
            if (relacionamento.IsNew())
                Add(relacionamento);
            else
                Update(relacionamento);
        }


        private void Add(Relacionamento relacionamento)
        {
            using (ISession session = FluentSessionFactory.abrirSession())
            {
                using (ITransaction transacao = session.BeginTransaction())
                {
                    try
                    {
                        session.Save(relacionamento);
                        transacao.Commit();
                    }
                    catch (Exception e)
                    {
                        if (!transacao.WasCommitted)
                        {
                            transacao.Rollback();
                        }
                        throw new Exception("Erro ao inserir relacionamento: " + e.Message);
                    }
                }
            }
        }


        private void Update(Relacionamento relacionamento)
        {
            using (ISession session = FluentSessionFactory.abrirSession())
            {
                using (ITransaction transacao = session.BeginTransaction())
                {
                    try
                    {
                        session.Merge(relacionamento);
                        transacao.Commit();
                    }
                    catch (Exception e)
                    {
                        if (!transacao.WasCommitted)
                        {
                            transacao.Rollback();
                        }
                        throw new Exception("Erro ao atualizar relacionamento: " + e.Message);
                    }
                }
            }
        }
    }
}
