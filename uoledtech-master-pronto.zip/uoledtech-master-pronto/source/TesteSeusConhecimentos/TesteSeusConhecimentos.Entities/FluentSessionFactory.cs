﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using FluentNHibernate.Cfg;
using FluentNHibernate.Cfg.Db;
using NHibernate;
using System.Configuration;
using NHibernate.Tool.hbm2ddl;

namespace TesteSeusConhecimentos.Entities
{
    public class FluentSessionFactory
    {

        private static ISessionFactory session;
        private static string connectionString = @"Data Source=(localdb)\mssqllocaldb;AttachDbFilename=|DataDirectory|\TesteSeusConhecimentos.mdf;Integrated Security=True";

        public static ISessionFactory criarSession()
        {
            
            if (session != null)
                return session;

            IPersistenceConfigurer configDB = MsSqlConfiguration.MsSql2012.ConnectionString(connectionString);

            var configMap = Fluently.Configure().Database(configDB).Mappings(c => c.FluentMappings.AddFromAssemblyOf<Mapping.UserMap>()).Mappings(c => c.FluentMappings.AddFromAssemblyOf<Mapping.RelacionamentoMap>()).Mappings(c => c.FluentMappings.AddFromAssemblyOf<Mapping.EnterpriseMap>());
            configMap.ExposeConfiguration(cfg =>
            {
                var exporter = new SchemaUpdate(cfg);
                exporter.Execute(true, true);
            });
            try
            {
               
                session = configMap.BuildSessionFactory();
            }
            catch (Exception ex)
            {

                throw;
            }

            return session;

        }


        public static ISession abrirSession()
        {
            return criarSession().OpenSession();
        }

    }
}
