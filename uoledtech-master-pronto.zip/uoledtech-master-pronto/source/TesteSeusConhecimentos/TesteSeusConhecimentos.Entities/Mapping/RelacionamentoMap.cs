﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using FluentNHibernate.Mapping;
using TesteSeusConhecimentos.Entities;

namespace TesteSeusConhecimentos.Entities.Mapping
{
   public class RelacionamentoMap : ClassMap<Relacionamento>
    {

        public RelacionamentoMap()
        {
            Id(c => c.IdRelacionamento);
            References(x => x.Usuario)
                .Not.Nullable()
                .Cascade.SaveUpdate()
                .Column("IdUser");
            References(x => x.Empresa)
                .Not.Nullable()
                .Cascade.SaveUpdate()
                .Column("IdEnterprise");
            Table("TesteSeusConhecimentos.RelacionamentoData");
        }
    }
}
