﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace TesteSeusConhecimentos.Entities
{
    public class Relacionamento
    {
        public virtual int IdRelacionamento { get; set; }
        public virtual Enterprise Empresa { get; set; }
        public virtual User Usuario { get; set; }

        public Relacionamento()
        {

        }

        public Relacionamento(int idRelacionamento, User User, Enterprise Enterprise)
        {
            this.IdRelacionamento = idRelacionamento;
            this.Usuario = User;
            this.Empresa = Enterprise;
        }

        public virtual bool IsNew()
        {
            return this.IdRelacionamento == 0;
        }
    }
}
